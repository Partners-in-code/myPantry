package com.myPantry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyPantryApplicationTests {

	@Test
	void contextLoads() {
	}

}
