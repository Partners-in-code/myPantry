package com.myPantry.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.myPantry.domain.Product;
import com.myPantry.domain.User;
import com.myPantry.service.ProductService;
import com.myPantry.service.UserService;

@Controller
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService productService;

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String addProduct(Model model) {
		Product product = new Product();
		model.addAttribute("product", product);
		return "addProduct";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addProductPost(Model model, @ModelAttribute("product") Product product, Principal principal,
			HttpServletRequest request) throws Exception {

		User user = userService.findByUsername(principal.getName());
		model.addAttribute("user", user);

		if (user == null) {
			throw new Exception("User not found");
		}
		product.setUser(user);
		productService.save(product);

		MultipartFile productImage = product.getProductImage();

		try {
			byte[] bytes = productImage.getBytes();
			String name = product.getId() + ".png";
			BufferedOutputStream stream = new BufferedOutputStream(
					new FileOutputStream(new File("src/main/resources/static/image/product/" + name)));
			stream.write(bytes);
			stream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "redirect:productList";
	}

	@RequestMapping("/productInfo")
	public String productInfo(@RequestParam("id") Long id, Model model) {
		Product product = productService.findOne(id);
		model.addAttribute("product", product);

		return "productInfo";
	}

	@RequestMapping("/updateProduct")
	public String updateProduct(@RequestParam("id") Long id, Model model) {
		Product product = productService.findOne(id);
		model.addAttribute("product", product);

		return "updateProduct";
	}

	@RequestMapping(value = "/updateProduct", method = RequestMethod.POST)
	public String updateProductPost(@ModelAttribute("product") Product product, Principal principal,
			HttpServletRequest request) {

		User user = userService.findByUsername(principal.getName());
		product.setUser(user);
		productService.save(product);

		MultipartFile productImage = product.getProductImage();

		if (!productImage.isEmpty()) {
			try {
				byte[] bytes = productImage.getBytes();
				String name = product.getId() + ".png";

				Files.delete(Paths.get("src/main/resources/static/image/product/" + name));

				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(new File("src/main/resources/static/image/product/" + name)));
				stream.write(bytes);
				stream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return "redirect:/product/productList";
	}

	@RequestMapping("/productList")
	public String productList(Model model, Principal principal) {
		User user = userService.findByUsername(principal.getName());
		model.addAttribute("user", user);
		List<Product> productList = productService.findAll(user.getId());
		model.addAttribute("productList", productList);

		return "productList";

	}

	@RequestMapping("/productshelf")
	public String productshelf(Model model, Principal principal) {
		User user = userService.findByUsername(principal.getName());
		model.addAttribute("user", user);
		List<Product> productList = productService.findAll(user.getId());
		model.addAttribute("productList", productList);
		return "productshelf";
	}

	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	public String remove(@ModelAttribute("id") String id, Model model,Principal principal) {
		User user = userService.findByUsername(principal.getName());
		productService.removeOne(Long.parseLong(id.substring(11)));
		List<Product> productList = productService.findAll(user.getId());
		model.addAttribute("productList", productList);

		return "redirect:productList";
	}
}
